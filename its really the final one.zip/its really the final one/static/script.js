const recognition = new webkitSpeechRecognition();
recognition.continuous = false;
recognition.lang = 'en-US';
recognition.interimResults = false;


const synthesis = window.speechSynthesis;


let isListening = false;


const startListeningButton = document.getElementById("start-listening-button");

document.getElementById("user-input").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

function speak(text) {
    var utterance = new SpeechSynthesisUtterance();
    utterance.text = text;
    synthesis.speak(utterance);
}

function showNotification() {
    const chatContainer = document.querySelector(".chat-container");
    const notification = document.createElement("div");
    notification.textContent = "Microphone is on";
    notification.classList.add("notification");
    chatContainer.appendChild(notification);

   
    notification.offsetHeight; 
    notification.classList.add("show"); 
    setTimeout(() => {
        notification.classList.remove("show"); 
        setTimeout(() => {
            chatContainer.removeChild(notification);
        }, 500); 
    }, 3000); 
}

function startListening() {
    recognition.start();
    isListening = true;
    showNotification();
}


recognition.onresult = function(event) {
    var transcript = event.results[0][0].transcript;
    appendMessage("You: " + transcript, "right-message");
    fetch("/send-message", {
        method: "POST",
        body: JSON.stringify({ message: transcript }),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.response) {
            setTimeout(() => {
                appendMessage("Bot: " + data.response, "left-message");
                setTimeout(() => {
                    speak(data.response);
                }, 500); // Adjust the delay to sync with message appearance
            }, 300); // Adjust the delay as needed
        } else {
            setTimeout(() => {
                appendMessage("Bot: I'm sorry, I didn't understand that.", "left-message");
                setTimeout(() => {
                    speak("I'm sorry, I didn't understand that.");
                }, 500); // Adjust the delay to sync with message appearance
            }, 300); // Adjust the delay as needed
        }
    })
    .catch(error => {
        console.error('Error sending message:', error);
        setTimeout(() => {
            appendMessage("Bot: Oops! Something went wrong.", "left-message");
            setTimeout(() => {
                speak("Oops! Something went wrong.");
            }, 500); // Adjust the delay to sync with message appearance
        }, 300); // Adjust the delay as needed
    });
}

recognition.onerror = function(event) {
    console.error('Speech recognition error:', event.error);
    isListening = false;
}

function appendMessage(message, side) {
    var chatBox = document.getElementById("chat-box");
    var newMessage = document.createElement("div");
    newMessage.textContent = message;
    newMessage.classList.add("message", side);
    chatBox.appendChild(newMessage);
    
    // Delay the appearance of the message
    setTimeout(() => {
        newMessage.style.opacity = "1";
        newMessage.style.transform = "translateY(0)";
    }, 100); // Adjust the delay as needed
    
    // Scroll to the bottom of the chat box
    chatBox.scrollTop = chatBox.scrollHeight;
}

function sendMessage() {
    var userInput = document.getElementById("user-input").value;
    if (userInput.trim() !== "") {
        appendMessage("You: " + userInput, "right-message");
        document.getElementById("user-input").value = "";
        fetch("/send-message", {
            method: "POST",
            body: JSON.stringify({ message: userInput }),
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.response) {
                // Delay the bot message slightly more than the user message
                setTimeout(() => {
                    appendMessage("Bot: " + data.response, "left-message");
                    speak(data.response);
                }, 700); // Adjust the delay as needed
            } else {
                setTimeout(() => {
                    appendMessage("Bot: I'm sorry, I didn't understand that.", "left-message");
                    speak("I'm sorry, I didn't understand that.");
                }, 400); // Adjust the delay as needed
            }
        })
        .catch(error => {
            console.error('Error sending message:', error);
            setTimeout(() => {
                appendMessage("Bot: Oops! Something went wrong.", "left-message");
            }, 400); // Adjust the delay as needed
        });
    }
}

function toggleChat() {
    const chatContainer = document.querySelector(".chat-container");
    const chatButton = document.querySelector(".chat-button");

    if (chatContainer.classList.contains("active")) {
        // Remove active class after a small delay for transition effect
        setTimeout(() => {
            chatContainer.classList.remove("active");
        }, 30); // Adjust timing to match your transition time
    } else {
        chatContainer.classList.add("active");
        // Positioning chat container relative to the chat button
        const chatButtonRect = chatButton.getBoundingClientRect();
        chatContainer.style.top =  "260px";
        chatContainer.style.bottom = "1000px";
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content').forEach(section => {
        section.style.display = 'none';
    });

    // Show the selected section
    const sectionToShow = document.getElementById(sectionId);
    if (sectionToShow) {
        sectionToShow.style.display = 'block';
    }
}

// Optional: Show the home section by default on page load
document.addEventListener('DOMContentLoaded', () => {
    showSection('home');
});