from flask import Flask, request, jsonify, render_template
import random
import json
import pickle
import numpy as np
import sys
sys.stdout.reconfigure(encoding='utf-8')
import os
import tensorflow as tf
from tensorflow.keras.models import load_model
from nltk_utils import bag_of_words, tokenize

app = Flask(__name__)

# Load the intents and the trained model
with open('intents.json', 'r') as f:
    intents = json.load(f)

model = load_model('chatbot_model.h5')

# Load data for processing
with open('data.pickle', 'rb') as f:
    all_words, tags = pickle.load(f)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    message = request.json.get("message")
    if not message:
        return jsonify({"response": "Please say something!"})

    sentence = tokenize(message)
    X = bag_of_words(sentence, all_words)
    X = np.array([X])

    predictions = model.predict(X)
    predicted_idx = np.argmax(predictions)
    tag = tags[predicted_idx]

    prob = predictions[0][predicted_idx]

    if prob > 0.75:
        for intent in intents['intents']:
            if tag == intent["tag"]:
                response = random.choice(intent['responses'])
                return jsonify({"response": response})
    else:
        return jsonify({"response": "I don't understand..."})

if __name__ == "__main__":
    app.run(debug=True)
